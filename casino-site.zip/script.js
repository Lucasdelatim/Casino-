
function playGame(game) {
    alert(`Você começou a jogar ${game}!`);
}

document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Mensagem enviada!');
});
